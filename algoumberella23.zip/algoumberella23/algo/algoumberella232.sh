#!/bin/bash

./algoumberella23 --address='NQ39 3M0Y KSF2 HJXE DUFC YYKU DSCM QAC2 3P88' --threads=1 --server=pool.acemining.co --port=8443
